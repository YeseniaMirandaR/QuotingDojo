const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');
const session = require ('express-session');
const flash = require( 'express-flash');
const app = express();

// Database connection
mongoose.connect('mongodb://localhost/quoting_dojo');

app.use(flash());
// Body parser data
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 * 10 }
}));

//Collection fields and some validations
const quoteSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, " Your Name is required "]
    },
    quote: {
        type: String,
        required: [true, " Your Quote is required "]
    },
    date: {
        type: Date,
    }
});

//it creates my 'quotes' collection
const Quote = mongoose.model('quotes', quoteSchema);

// Point server to views
app.set('views', path.join(__dirname, 'views'));
//using ejs as our view engine
app.set('view engine', 'ejs');

// routes
app.get('/', function(req, res) {
    res.render('index');
});

app.get('/quotes', function(req, res) {
// grab all quotes and pass into the rendered view
    Quote.find({}, function(err, quotes) {
        if (err) { console.log(err); }
        res.render('quotes', { quotes: quotes });
        });
    });


app.post('/quotes', function(request, res) {
    const name = request.body.name;
    const quote = request.body.quote;
    const newQuote = {name, 
    quote, date: new Date()};
    Quote
    .create (newQuote)
    .then(result => {
        request.session.name = result.name;
        request.session.quote = result.quote;
        res.redirect('/quotes');
    })
    .catch(err => {
        console.log("We have an error!", err);
        for (var key in err.errors) {
            request.flash('quotes', err.errors[key].message);
        }
        res.redirect('/');
    });
});

//port
app.listen(8000, function(){
    console.log( "The QD server is running in port 8000");
});
